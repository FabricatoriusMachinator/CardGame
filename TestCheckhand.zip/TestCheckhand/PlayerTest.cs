using Microsoft.VisualStudio.TestTools.UnitTesting;
using CardGame;

namespace TestCheckhand
{
    [TestClass]
    public class PlayerTest
    {
        [TestMethod]
        public void TestCeckHandCardsPopularIsDiamond()
        {
            //Arrange test
            Card[] cards = new Card[5];
            cards[0] = new Card("Ace", "Diamonds");
            cards[1] = new Card("King", "Diamonds");
            cards[2] = new Card("Queen", "Diamonds");
            cards[3] = new Card("Two", "Hearts");
            cards[4] = new Card("Seven", "Hearts");
            Player player = new Player("Player1");
            player.hand = cards;

            //Act
            player.checkHand();

            //Assert
            Assert.IsTrue(player.popular == "Diamonds");
        }

        //[TestMethod]
        //public void TestDiscardCard()
        //{
        //    //Arrange
        //    Card[] cards = new Card[5];
        //    cards[0] = new Card("Ace", "Diamonds");
        //    cards[1] = new Card("King", "Diamonds");
        //    cards[2] = new Card("Queen", "Diamonds");
        //    cards[3] = new Card("Two", "Hearts");
        //    cards[4] = new Card("Seven", "Hearts");
        //    Player player = new Player("Player1");
        //    player.hand = cards;

        //    GameManagr gameMGMT = GameManagr.Instance;
        //    player.gameMGMT = gameMGMT;


        //    //Act
        //    player.discard();

        //    //Assert

        //  Can't test since GameManagr doesn't like public
        //}

        [TestMethod]
        public void TestIfDeckShuffles()
        {
            //Arrange test
            Deck deck = new Deck();
            Deck deck2 = new Deck();
            deck.createDeck();
            deck2.createDeck();
            //Act
            deck2.Shuffle();

            //Assert
            Assert.AreNotEqual(deck2, deck);
        }
    }
}
